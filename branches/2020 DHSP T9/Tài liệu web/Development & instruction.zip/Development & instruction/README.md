Môi trường:

node 8.11.1

Run:

- npm install
- npm install --global gulp-cli
- gulp watch
